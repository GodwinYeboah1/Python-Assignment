from __future__ import unicode_literals

from django.apps import AppConfig


class RandomGeneratorAppConfig(AppConfig):
    name = 'random_generator_app'
